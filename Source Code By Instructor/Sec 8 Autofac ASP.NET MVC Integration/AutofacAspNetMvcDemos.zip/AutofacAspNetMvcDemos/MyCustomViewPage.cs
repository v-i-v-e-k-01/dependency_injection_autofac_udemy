﻿namespace AutofacAspNetMvcDemos
{
  public abstract class MyCustomViewPage
  {
    public ILogger Logger { get; set; }
  }
}