﻿namespace AutofacAspNetMvcDemos
{
  public class TextFileLogger : ILogger
  {
    public void Log(string message)
    {
      // todo
    }
  }
}